var typed = (".typing",{
    strings:["","Web developer","Web designer"],
    typeSpeed:100,
    BackSpeed:60,
    loop:true
})


